<div class="video-sec vid-bg">
    <div class="card">
        <div class="card-body">
            <a href="<?php echo e($item->link); ?>" class="video-thumbnail" data-fancybox="">
                <div class="play-icon">
                    <i class="fa-solid fa-play"></i>
                </div>
                <img class="img-fluid video-thumb" src="<?php echo e(asset('/')); ?>assets/images/thumbnail/<?php echo e($item->thumbnail); ?>"
                  alt="">
            </a>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\tjo\resources\views/front/components/about-video.blade.php ENDPATH**/ ?>