<?php $__env->startSection('main-body'); ?>
<div class="main-body">

    <div class="card">
        <h4 class="card-header">Edit live</h4>
        <div class="card-body">
            <div class="row">
                <div class="basic-form">
                    <form action="<?php echo e(route('live.update',$live->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="mb-3">
                            <label class="me-sm-2">Course <b class="text-danger">*</b>:</label>
                            <select class="me-sm-2 default-select form-control wide" name="course_id"
                              id="inlineFormCustomSelect">
                                <option selected>Select One </option>
                                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->course_id); ?>" <?php if( $item->course_id == $live->course_id): ?>
                                    selected
                                    <?php endif; ?>

                                    ><?php echo e($item->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="banner" class="form-label">Banner <b class="text-danger">*</b>:</label>
                            <canvas id="canv1"></canvas>
                            <input type="file" class="form-file-input form-control " name="banner"
                              placeholder="Type Here ... " multiple="false" accept="image/*" id=finput1
                              onchange="upload()">
                        </div>

                        <div class="mb-3">
                            <label for="start_date" class="form-label">Class Start Date <b
                                  class="text-danger">*</b>:</label>
                            <input type="date" name="start_date" class="datepicker-default form-control" id="start_date"
                              value="<?php echo e($live->start_date); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="end_date" class="form-label">Registration End Date <b
                                  class="text-danger">*</b>:</label>
                            <input type="date" name="end_date" class="datepicker-default form-control" id="end_date"
                              value="<?php echo e($live->end_date); ?>">
                        </div>
                        <button type="submit" class="btn btn-primary">
                            submit
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    function upload(){
    var imgcanvas = document.getElementById("canv1");
    var fileinput = document.getElementById("finput1");
    var image = new SimpleImage(fileinput);
    image.drawTo(imgcanvas);
  }
  function upload2(){
    var imgcanvas = document.getElementById("canv2");
    var fileinput = document.getElementById("finput2");
    var image = new SimpleImage(fileinput);
    image.drawTo(imgcanvas);
  }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tjo\resources\views/admin/pages/live/edit.blade.php ENDPATH**/ ?>