<script data-cfasync="false" src="../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>
<script src="<?php echo e(asset('/')); ?>assets/front/js/jquery-3.6.0.min.js"></script>

<script src="<?php echo e(asset('/')); ?>assets/front/js/bootstrap.bundle.min.js"></script>

<script src="<?php echo e(asset('/')); ?>assets/front/js/jquery.waypoints.js"></script>
<script src="<?php echo e(asset('/')); ?>assets/front/js/jquery.counterup.min.js"></script>

<script src="<?php echo e(asset('/')); ?>assets/front/plugins/select2/js/select2.min.js"></script>

<script src="<?php echo e(asset('/')); ?>assets/front/js/owl.carousel.min.js"></script>

<script src="<?php echo e(asset('/')); ?>assets/front/plugins/slick/slick.js"></script>

<script src="<?php echo e(asset('/')); ?>assets/front/plugins/aos/aos.js"></script>

<script src="<?php echo e(asset('/')); ?>assets/front/js/script.js"></script>
<?php /**PATH C:\xampp\htdocs\tjo\resources\views/front/include/script.blade.php ENDPATH**/ ?>