<?php $__env->startSection('main-body'); ?>
<div class="main-body">

    <div class="card">
        <h4 class="card-header">Create Course</h4>
        <div class="card-body">
            <div class="row">
                <div class="basic-form">
                    <form>
                        <div class="mb-3">
                            <label for="title" class="form-label">Title <b class="text-danger">*</b>:</label>
                            <input type="text" class="form-control input-default " name="title"
                              placeholder="Type Here ... ">
                        </div>
                        <div class="mb-3">
                            <label for="quickview" class="form-label">Quick view <b class="text-danger">*</b>:</label>
                            <textarea type="text" class="form-control input-default " name="quickview"
                              placeholder="Type Here ... "></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="preview" class="form-label">Preview <b class="text-danger">*</b>:</label>
                            <input type="text" class="form-control input-default " name="preview"
                              placeholder="Type Here ... ">
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label">description <b
                                  class="text-danger">*</b>:</label>
                            <div id="editor"></div>
                        </div>
                        <div class="mb-3">
                            <label for="duration" class="form-label">duration <b class="text-danger">*</b>:</label>
                            <input type="text" class="form-control input-default " name="duration"
                              placeholder="Type Here ... ">
                        </div>
                        <div class="mb-3">
                            <label for="start_date" class="form-label">start_date <b class="text-danger">*</b>:</label>
                            <input type="text" class="form-control" placeholder="2017-06-04" id="mdate">
                        </div>
                        <div class="mb-3">
                            <label for="end_date" class="form-label">end_date <b class="text-danger">*</b>:</label>
                            <input type="text" class="form-control" placeholder="2017-06-04" id="mdate">
                        </div>
                        <div class="mb-3">
                            <label for="type" class="form-label">type <b class="text-danger">*</b>:</label>
                            <input type="text" class="form-control input-default " name="type"
                              placeholder="Type Here ... ">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tjo\resources\views/admin/pages/course/create.blade.php ENDPATH**/ ?>