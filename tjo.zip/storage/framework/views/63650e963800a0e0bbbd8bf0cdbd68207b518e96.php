

<?php $__env->startSection('main-body'); ?>
<div class="main-body">
    <div class="page-content">
        <div class="container">
            <div class="row">

                <div class="col-xl-3 col-md-4 theiaStickySidebar">
                    <?php echo $__env->make('front.pages.dashboard.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>


                <div class="col-xl-9 col-md-8">
                    <?php echo $__env->yieldContent('dashboard-body'); ?>
                </div>

            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tjo\resources\views/front/pages/dashboard/app/app.blade.php ENDPATH**/ ?>