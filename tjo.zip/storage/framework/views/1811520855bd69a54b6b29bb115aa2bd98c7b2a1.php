<?php $__env->startSection('main-body'); ?>
<div class="main-body">

    <div class="card">
        <h4 class="card-header">checkout</h4>
        <div class="card-body">
            <div class="row">
                <div class="card">
                    
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="example5" class="text-center display" style="min-width: 845px">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Course Type</th>
                                    <th>Course ID</th>
                                    <th>Course Name</th>
                                    <th>Student Name</th>
                                    <th>Student ID</th>
                                    <th>email</th>
                                    <th>phone</th>
                                    <th>Payment</th>
                                    <th>paid</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__currentLoopData = $checkouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->id); ?></td>
                                    <td>

                                        
                                        <?php if( $item->hasLive ): ?>
                                        Live Course
                                        <?php else: ?>
                                        Reguler Course
                                        <?php endif; ?>

                                    </td>
                                    
                                    <td><?php echo e($item->course->course_id); ?></td>
                                    <td><?php echo e($item->course->title); ?></td>
                                    <td><?php echo e($item->user->name); ?></td>
                                    <td><?php echo e($item->user->id); ?></td>
                                    <td><?php echo e($item->user->email); ?></td>
                                    <td><?php echo e($item->user->phone); ?></td>
                                    <td><?php echo e($item->course->price); ?></td>
                                    <td><?php echo e($item->course->price); ?></td>
                                    <td>
                                        <?php if($item->type == 0): ?>
                                        <span class="badge light badge-primary">pending</span>
                                        <?php elseif($item->type == 1): ?>
                                        <span class="badge light badge-success">approved</span>
                                        <?php else: ?>
                                        <span class="badge light badge-danger">declined</span>
                                        <?php endif; ?>

                                    </td>
                                    <td>
                                        <div class="d-flex">

                                            <form action="<?php echo e(route('checkout.accept',$item->id)); ?>"
                                              id="accept<?php echo e($item->id); ?>" method="get">
                                                <?php echo csrf_field(); ?>
                                            </form>
                                            <button class="btn btn-success shadow btn-xs sharp"
                                              onclick="acceptItem(<?php echo e($item->id); ?>);"><i
                                                  class="fa fa-check"></i></button>
                                            <form action="<?php echo e(route('checkout.decline',$item->id)); ?>"
                                              id="decline<?php echo e($item->id); ?>" method="get">
                                                <?php echo csrf_field(); ?>
                                            </form>
                                            <button class="btn btn-danger shadow btn-xs sharp"
                                              onclick="deleteItem(<?php echo e($item->id); ?>);"><i
                                                  class="fa fa-trash"></i></button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>

                            
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    function deleteItem(id) {
    // console.log(id);

    Swal.fire({
  title: 'Are you sure want to decline this?',
  icon: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Yes, Decline it!'
}).then((result) => {
  if (result.isConfirmed) {
    document.getElementById(`decline${id}`).submit();
  }
})

    }
    function acceptItem(id) {
    // console.log(id);

    Swal.fire({
  title: 'Are you sure want to approved this?',
  icon: 'info',
  showCancelButton: true,
  confirmButtonColor: '#C3E88D',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Yes, accept it it!'
}).then((result) => {
  if (result.isConfirmed) {
    document.getElementById(`accept${id}`).submit();
  }
})

    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tjo\resources\views/admin/pages/checkout/index.blade.php ENDPATH**/ ?>