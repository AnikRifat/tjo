

<?php $__env->startSection('main-body'); ?>
<div class="main-body">
    <img src="<?php echo e(asset('/assets/images/success.png')); ?>" alt="">
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.master.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tjo\resources\views/front/pages/checkout-success.blade.php ENDPATH**/ ?>