<?php $__env->startSection('main-body'); ?>
<div class="main-body">

    <div class="card">
        <h4 class="card-header">Demo Page</h4>
        <div class="card-body">
            <div class="row">

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tjo\resources\views/admin/index.blade.php ENDPATH**/ ?>