<!--**********************************
            Nav header start
        ***********************************-->
<div class="nav-header">
    <a href="index-2.html" class="brand-logo">
        <img src="<?php echo e(asset('/')); ?>assets/images/content/<?php echo e($content->logo); ?>" class="img-fluid" alt="Logo">
    </a>

    <div class="nav-control">
        <div class="hamburger">
            <span class="line"></span><span class="line"></span><span class="line"></span>
        </div>
    </div>
</div>
<!--**********************************
        Nav header end
    ***********************************-->
<?php /**PATH C:\xampp\htdocs\tjo\resources\views/admin/inc/nav.blade.php ENDPATH**/ ?>