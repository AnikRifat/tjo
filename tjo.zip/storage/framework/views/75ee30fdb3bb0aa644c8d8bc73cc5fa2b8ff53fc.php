<?php $__env->startSection('main-body'); ?>
<div class="main-body">

    <section class="home-slide d-flex align-items-center">
        <div class="container">
            <div class="row ">
                <div class="col-md-7">
                    <div class="home-slide-face aos" data-aos="fade-up">
                        <div class="home-slide-text ">
                            
                            <h1><?php echo $content->title; ?></h1>
                        </div>

                        <div class="trust-user">
                            <p class="text-small"><?php echo e($content->sub_title); ?></p>
                        </div>
                        
                    </div>
                </div>
                <div class="col-md-5 d-flex align-items-center">
                    <div class="girl-slide-img aos" data-aos="fade-up">
                        <img src="<?php echo e(asset('/')); ?>assets/images/content/<?php echo e($content->image); ?>" alt="">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="section about-us" id="about">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-md-12">
                    <div class="section-header aos aos-init aos-animate" data-aos="fade-up">
                        <div class="section-sub-head">
                            <span>About</span>
                            <h2>Teacher Jack</h2>
                        </div>
                    </div>
                    <div class="section-text aos aos-init aos-animate" data-aos="fade-up">
                        <?php echo $content->about; ?>

                    </div>

                </div>
                <div class="col-lg-7 col-12">
                    <div class="about-video  pt-5">
                        <div class="container">
                            <div class="row">
                                <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-3 col-md-4 col-6">
                                    <?php echo $__env->make('front.components.about-video', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="category" id="courses">

        <div class="container">

        </div>
    </section>

    <section class="section trend-course">
        <div class="container">
            <div class="section-header aos aos-init aos-animate" data-aos="fade-up">
                <div class="section-sub-head ">
                    <h2 class="text-center">Packages</h2>
                </div>
            </div>
            <div class="course-widget">
                <div class="row">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <?php echo $__env->make('front.components.category-card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
            

        </div>
    </section>

    <?php if($testimonials): ?>
    <section class="section trend-course" id="testimonials">
        <div class="container">
            <div class="section-header aos" data-aos="fade-up">
                <div class="section-sub-head">
                    <h2>What Students Say About Me</h2>
                </div>

            </div>


            <div class="feature-instructors">
                <div class="owl-carousel instructors-course owl-theme aos" data-aos="fade-up">
                    <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="instructors-widget">
                        <div class="instructors-content">
                            <div class="row">
                                <div class="col-3">
                                    <img class="text-image"
                                      src="<?php echo e(asset('/assets/images/testimonial')); ?>/<?php echo e($item->image); ?>" alt="">
                                </div>
                                <div class="col-9">
                                    <h5><?php echo e($item->name); ?></h5>
                                    <p><?php echo e($item->title); ?></p>
                                </div>
                                <div class="col-12"></div>
                                <span><?php echo e($item->text); ?></span>
                            </div>


                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>
            </div>
    </section>
    <?php endif; ?>




    <section class="section master-skill skill" id="hit">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 col-md-12">
                    <div class="section-header aos" data-aos="fade-up">
                        <div class="section-sub-head">
                            <h2>Steps for Success</h2>
                        </div>
                    </div>

                    <div class="course-widget ">
                        <div class="row">
                            <div class="col-lg-12 col-12">
                                <div class="course-full-width">
                                    <div class="blur-border course-radius align-items-center aos aos-init aos-animate"
                                      data-aos="fade-up">
                                        <div class="online-course d-flex align-items-center justify-content-center">
                                            <div class="course-img">
                                                <img src="<?php echo e(asset('/assets/front')); ?>/img/proccess/1.png" alt="">
                                            </div>
                                            <div class="course-inner-content">
                                                <p>Get a Schedule</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-12 d-flex">
                                <div class="course-full-width">
                                    <div class="blur-border course-radius aos aos-init aos-animate" data-aos="fade-up">
                                        <div class="online-course d-flex align-items-center">
                                            <div class="course-img">
                                                <img src="<?php echo e(asset('/assets/front')); ?>/img/proccess/2.png" alt="">
                                            </div>
                                            <div class="course-inner-content">
                                                <p>Fix a Time</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-12 d-flex">
                                <div class="course-full-width">
                                    <div class="blur-border course-radius aos aos-init aos-animate" data-aos="fade-up">
                                        <div class="online-course d-flex align-items-center">
                                            <div class="course-img">
                                                <img src="<?php echo e(asset('/assets/front')); ?>/img/proccess/3.png" alt="">
                                            </div>
                                            <div class="course-inner-content">
                                                <p>Make Payment</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12 col-12 d-flex">
                                <div class="course-full-width">
                                    <div class="blur-border course-radius aos aos-init aos-animate" data-aos="fade-up">
                                        <div class="online-course d-flex align-items-center justify-content-center">
                                            <div class="course-img">
                                                <img src="<?php echo e(asset('/assets/front')); ?>/img/proccess/4.png" alt="">
                                            </div>
                                            <div class="course-inner-content">
                                                <p>Attend Class</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5 col-md-12 text-center">
                    <div class="career-img aos" data-aos="fade-up">
                        <img src="<?php echo e(asset('/')); ?>assets/front/img/join.png" style="
                        height: 20rem;
                        /* margin: 0px auto; */
                    " alt="" class="img-fluid">
                    </div>
                </div>
            </div>
        </div>
    </section>



</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tjo\resources\views/front/index.blade.php ENDPATH**/ ?>