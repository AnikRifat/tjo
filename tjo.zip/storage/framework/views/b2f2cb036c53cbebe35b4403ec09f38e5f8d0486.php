
<?php $__env->startSection('main-body'); ?>
<div class="main-body">

    <div class="card">
        <h4 class="card-header">testimonial</h4>
        <div class="card-body">
            <div class="row">
                <div class="card">
                    <div class="card-header">
                        <a href="<?php echo e(route('testimonial.create')); ?>" class="btn btn-primary">+ Add testimonial</a>

                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="example5" class="text-center display" style="min-width: 845px">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>name</th>
                                        <th>title</th>
                                        <th>text</th>
                                        <th>image</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($testimonial->id); ?></td>
                                        <td><?php echo e($testimonial->name); ?></td>
                                        <td><?php echo e($testimonial->title); ?></td>
                                        <td><?php echo e($testimonial->text); ?></td>
                                        <td><img
                                              src="<?php echo e(asset('/')); ?>assets/images/testimonial/<?php echo e($testimonial->image); ?>"
                                              class="img-fluid" alt=""></td>
                                        <td>
                                            <div class="d-flex">
                                                <a href="<?php echo e(route('testimonial.edit',$testimonial->id)); ?>"
                                                  class="btn btn-primary shadow btn-xs sharp me-1"><i
                                                      class="fas fa-pencil-alt"></i></a>
                                                <form action="<?php echo e(route('testimonial.destroy',$testimonial->id)); ?>"
                                                  id="form<?php echo e($testimonial->id); ?>" method="get">
                                                    <?php echo csrf_field(); ?>
                                                </form>
                                                <button class="btn btn-danger shadow btn-xs sharp"
                                                  onclick="deleteItem(<?php echo e($testimonial->id); ?>);"><i
                                                      class="fa fa-trash"></i></button>
                                            </div>
                                        </td>


                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    function deleteItem(id) {
    // console.log(id);

    Swal.fire({
  title: 'Are you sure?',
  text: "You won't be able to revert this!",
  icon: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Yes, delete it!'
}).then((result) => {
  if (result.isConfirmed) {
    document.getElementById(`form${id}`).submit();
  }
})

    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tjo\resources\views/admin/pages/testimonial/index.blade.php ENDPATH**/ ?>