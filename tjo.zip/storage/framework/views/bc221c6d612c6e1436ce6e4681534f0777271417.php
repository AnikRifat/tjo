<?php $__env->startSection('dashboard-body'); ?>
<div class="settings-widget profile-details">
    <div class="settings-menu p-0">
        <div class="profile-heading subscription-group d-flex align-items-center">
            <div class="subscription-name">
                <h3>My Subscriptions</h3>
                <p>Here is list of package/product that you have subscribed.</p>
            </div>
        </div>
        <div class="monthly-subscribtion comman-space border-line">
            <?php if(count($enroledCourses) > 0): ?>
            <?php $__currentLoopData = $enroledCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="monthly-group">
                <div class="subscribtion-active">
                    <div class="active-btns">
                        <?php if($item->type == 0): ?>
                        <span class="badge light badge-primary">pending</span>
                        <?php elseif($item->type == 1): ?>
                        <span class="badge light badge-success">approved</span>
                        <?php else: ?>
                        <span class="badge light badge-danger">declined</span>
                        <?php endif; ?>
                    </div>
                    <h2>Course Title: <?php echo e($item->course->title); ?> </h2>
                    <p></p>
                </div>
                <div class="bill-name-group mt-3">
                    
                    <p><?php echo e($item->course->preview); ?></p>
                </div>

            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <h5>no subscriptions yet</h5>
            <?php endif; ?>


        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.pages.dashboard.app.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tjo\resources\views/front/pages/dashboard/index.blade.php ENDPATH**/ ?>