<header class="header header-page">
    <div class="header-fixed">
        <nav class="navbar navbar-expand-lg header-nav scroll-sticky add-header-bg">
            <div class="container ">
                <div class="navbar-header">
                    <a id="mobile_btn" href="javascript:void(0);">
                        <span class="bar-icon">
                            <span></span>
                            <span></span>
                            <span></span>
                        </span>
                    </a>
                    <a href="<?php echo e(url('/')); ?>" class="navbar-brand logo">
                        <img src="<?php echo e(asset('/')); ?>assets/images/content/<?php echo e($content->logo); ?>" class="img-fluid"
                          alt="Logo">
                    </a>
                </div>
                <div class="main-menu-wrapper">
                    <div class="menu-header">
                        <a href="<?php echo e(url('/')); ?>" class="menu-logo">
                            <img src="<?php echo e(asset('/')); ?>assets/images/content/<?php echo e($content->logo); ?>" class="img-fluid"
                              alt="Logo">
                        </a>
                        <a id="menu_close" class="menu-close" href="javascript:void(0);">
                            <i class="fas fa-times"></i>
                        </a>
                    </div>
                    <ul class="main-nav">
                        <?php if(Route::is('index') ): ?>
                        <li>
                            <a href="<?php echo e(url('/')); ?>">Home</a>
                        </li>
                        <li>
                            <a href="#about">About</a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('/courses')); ?>">Courses</a>
                        </li>
                        <li>
                            <a href="#testimonials">Testimonials</a>
                        </li>
                        <li>
                            <a href="#hit">How it Works</a>
                        </li>
                        <?php else: ?>
                        <li>
                            <a href="<?php echo e(url('/')); ?>">Home</a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('/')); ?>/#about">About</a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('/courses')); ?>">Courses</a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('/')); ?>/#testimonials">Testimonials</a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('/')); ?>/#hit">How it Works</a>
                        </li>
                        <?php endif; ?>


                        
                    </ul>
                </div>
                <ul class="nav header-navbar-rht">
                    <li class="nav-item user-nav">
                        <a href="#" class="dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                            <span class="user-img">
                                <img src="<?php echo e(asset('/')); ?>assets/images/user.jpg" alt="">
                                <span class="status online"></span>
                            </span>
                        </a>

                        <div class="users dropdown-menu dropdown-menu-right" data-popper-placement="bottom-end">
                            <?php if(auth()->guard()->check()): ?>
                            <div class="user-header">
                                <div class="avatar avatar-sm">
                                    <img src="<?php echo e(asset('/')); ?>assets/images/user.jpg" alt="User Image"
                                      class="avatar-img rounded-circle">
                                </div>
                                <div class="user-text">
                                    <h6><?php echo e(Auth::user()->name); ?></h6>
                                    <p class="text-muted mb-0">Student</p>
                                </div>
                            </div>
                            <a class="dropdown-item" href="<?php echo e(route('user.index')); ?>"><i class="feather-user me-1"></i>
                                Profile</a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button class="dropdown-item" type="submit"><i class="feather-log-out me-1"></i>
                                    logout</button>
                            </form>
                            <?php else: ?>
                            <a class="dropdown-item" href="<?php echo e(route('login')); ?>"><i class="feather-log-out me-1"></i>
                                Login</a>
                            <?php endif; ?>

                        </div>
                    </li>
                </ul>
            </div>
        </nav>
        <div class="sidebar-overlay"></div>
    </div>
</header>
<?php /**PATH C:\xampp\htdocs\tjo\resources\views/front/include/header.blade.php ENDPATH**/ ?>