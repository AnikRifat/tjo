<a href="<?php echo e(route('category.courses',$item->id)); ?>">
    <div class="feature-box text-center ">
        <div class="feature-bg">
            <div class="feature-header">
                <div class="feature-cont">
                    <div class="feature-text"><?php echo e($item->name); ?></div>
                </div>
                <div class="feature-icon">
                    <img src="<?php echo e(asset('/')); ?>assets/images/category/<?php echo e($item->image); ?>" alt="">
                </div>

            </div>
            
        </div>
    </div>
</a>
<?php /**PATH C:\xampp\htdocs\tjo\resources\views/front/components/category-card.blade.php ENDPATH**/ ?>