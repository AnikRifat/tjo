<!DOCTYPE html>
<html lang="en">


    <head>
        <?php echo $__env->make('front.include.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <?php echo $__env->yieldContent('style'); ?>

    <body>
        <div class="main-wrapper">
            <?php echo $__env->make('front.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldContent('main-body'); ?>
        </div>
        <?php echo $__env->make('front.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('front.include.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('script'); ?>
    </body>


</html>
<?php /**PATH C:\xampp\htdocs\tjo\resources\views/front/master/app.blade.php ENDPATH**/ ?>