<footer class="footer">

    <div class="footer-top">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-6">

                    <div class="footer-widget footer-about">
                        <div class="footer-logo">
                            <img src="<?php echo e(asset('/')); ?>assets/images/content/<?php echo e($content->logo); ?>" alt="logo">
                        </div>
                        <div class="footer-about-content">
                            <p><?php echo e($content->sub_title); ?>

                            </p>
                        </div>
                    </div>

                </div>
                <div class="col-lg-4 col-md-6">

                    <div class="footer-widget footer-menu">
                        <h2 class="footer-title">Links</h2>
                        <ul>
                            <?php if(Route::is('index') ): ?>
                            <li>
                                <a href="<?php echo e(url('/')); ?>">Home</a>
                            </li>
                            <li>
                                <a href="#about">About</a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('/courses')); ?>">Courses</a>
                            </li>
                            <li>
                                <a href="#testimonials">Testimonials</a>
                            </li>
                            <li>
                                <a href="#hit">How it Works</a>
                            </li>
                            <?php else: ?>
                            <li>
                                <a href="<?php echo e(url('/')); ?>">Home</a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('/')); ?>/#about">About</a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('/courses')); ?>">Courses</a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('/')); ?>/#testimonials">Testimonials</a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('/')); ?>/#hit">How it Works</a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>

                </div>

                <div class="col-lg-4 col-md-6">

                    <div class="footer-widget footer-contact">

                        <div class="footer-contact-info">
                            
                        <p class="mb-2">
                            <i class="fas fa-envelope"></i>
                            <?php echo e($contact->email); ?>

                        </p>
                        <p class="mb-2">
                            <i class="fas fa-phone"></i>
                            <?php echo e($contact->phone); ?>

                        </p>
                        <p class="mb-2">
                            <i class="fas fa-phone"></i>
                            <?php echo e($contact->phone2); ?>

                        </p>
                        <p class="mb-2">
                            <i class="fa-brands fa-weixin"></i>

                            <?php echo e($contact->wechat); ?>

                        </p>
                        <p class="mb-2">
                            <i class="fa-brands fa-qq"></i>
                            <?php echo e($contact->qq); ?>

                        </p>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container">

            <div class="copyright">
                <div class="row">
                    <div class="col-md-6">
                        <div class="">
                            <p class="mb-0">IT Partner: <a href="https://abaacorp.com/">Abaacorp.com.</a>


                            </p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="copyright-text">
                            <p class="mb-0">© 2022 TeacherJackOnline. All Rights Reserved.</p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    </div>


</footer>
<?php /**PATH C:\xampp\htdocs\tjo\resources\views/front/include/footer.blade.php ENDPATH**/ ?>