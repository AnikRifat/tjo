@extends('front.master.app')

@section('main-body')
<div class="main-body">
</div>
@endsection
