<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
<title>Dreams LMS</title>

<link rel="shortcut icon" type="image/x-icon" href="{{ asset('/') }}assets/front/img/favicon.svg">

<link rel="stylesheet" href="{{ asset('/') }}assets/front/css/bootstrap.min.css">

<link rel="stylesheet" href="{{ asset('/') }}assets/front/plugins/fontawesome/css/fontawesome.min.css">
<link rel="stylesheet" href="{{ asset('/') }}assets/front/plugins/fontawesome/css/all.min.css">

<link rel="stylesheet" href="{{ asset('/') }}assets/front/css/owl.carousel.min.css">
<link rel="stylesheet" href="{{ asset('/') }}assets/front/css/owl.theme.default.min.css">

<link rel="stylesheet" href="{{ asset('/') }}assets/front/plugins/slick/slick.css">
<link rel="stylesheet" href="{{ asset('/') }}assets/front/plugins/slick/slick-theme.css">

<link rel="stylesheet" href="{{ asset('/') }}assets/front/plugins/select2/css/select2.min.css">

<link rel="stylesheet" href="{{ asset('/') }}assets/front/plugins/aos/aos.css">

<link rel="stylesheet" href="{{ asset('/') }}assets/front/css/style.css">
