@extends('front.master.app')

@section('main-body')
<div class="main-body">
    <img src="{{ asset('/assets/images/success.png') }}" alt="">
</div>
@endsection