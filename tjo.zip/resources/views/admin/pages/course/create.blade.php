@extends('admin.layouts.app')
@section('main-body')
<div class="main-body">

    <div class="card">
        <h4 class="card-header">Create Course</h4>
        <div class="card-body">
            <div class="row">
                <div class="basic-form">
                    <form>
                        <div class="mb-3">
                            <label for="title" class="form-label">Title <b class="text-danger">*</b>:</label>
                            <input type="text" class="form-control input-default " name="title"
                              placeholder="Type Here ... ">
                        </div>
                        <div class="mb-3">
                            <label for="image" class="form-label">image <b class="text-danger">*</b>:</label>
                            <input type="text" class="form-control input-default " name="image"
                              placeholder="Type Here ... ">
                        </div>
                        <div class="mb-3">
                            <label for="image" class="form-label">image <b class="text-danger">*</b>:</label>
                            <input type="text" class="form-control input-default " name="image"
                              placeholder="Type Here ... ">
                        </div>
                        <div class="mb-3">
                            <label for="prerview" class="form-label">Prerview <b class="text-danger">*</b>:</label>
                            <textarea type="text" class="form-control input-default " name="prerview"
                              placeholder="Type Here ... "></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="intro" class="form-label">Intro <b class="text-danger">*</b>:</label>
                            <input type="text" class="form-control input-default " name="intro"
                              placeholder="Type Here ... ">
                        </div>
                        <div class="mb-3">
                            <label for="overview" class="form-label">overview <b class="text-danger">*</b>:</label>
                            <div id="editor"></div>
                        </div>
                        <div class="mb-3">
                            <label for="duration" class="form-label">Duration <b class="text-danger">*</b>:</label>
                            <input type="text" class="form-control input-default " name="duration"
                              placeholder="Type Here ... ">
                        </div>
                        <div class="mb-3">
                            <label for="classes" class="form-label">Total classes <b class="text-danger">*</b>:</label>
                            <input type="text" class="form-control input-default " name="classes"
                              placeholder="Type Here ... ">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
