@extends('admin.layouts.app')
@section('main-body')
<div class="main-body">

    <div class="card">
        <h4 class="card-header">Demo Page</h4>
        <div class="card-body">
            <div class="row">
                
            </div>
        </div>
    </div>
</div>
@endsection
